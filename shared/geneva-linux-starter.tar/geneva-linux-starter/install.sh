#!/bin/bash
echo Adding Azure packages repository...
echo 'deb [arch=amd64] http://packages.microsoft.com/repos/azurecore/ trusty main' | sudo tee -a /etc/apt/sources.list.d/azure.list

sudo apt-key adv --keyserver packages.microsoft.com --recv-keys 417A0893

sudo apt-get update

echo Installing Azure mdsd packages.

# if the azsec version is desired uncomment below and comment azure-mdsd installation
#sudo apt-get install -y azure-security azsec-mdsd azsec-monitor azsec-clamav
sudo apt-get install -y azure-mdsd

echo Configuring rsyslog.
sudo config-mdsd syslog -e rsyslog
