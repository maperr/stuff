#!/bin/bash

echo Updating cert permissions.
sudo chown syslog /etc/mdsd.d/gcskey.pem
sudo chmod 400 /etc/mdsd.d/gcskey.pem

echo Starting mdsd daemon.
sudo systemctl start mdsd

echo Logging a sample event.
logger -p local1.info "Event for mdsd onebox testing"

